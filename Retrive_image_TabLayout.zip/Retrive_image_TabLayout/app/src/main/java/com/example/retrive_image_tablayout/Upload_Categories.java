package com.example.retrive_image_tablayout;

public class Upload_Categories {
    String category;
    public Upload_Categories(){
        //if needed
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getCategory() {
        return category;
    }
}
